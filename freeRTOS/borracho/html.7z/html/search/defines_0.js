var searchData=
[
  ['scvi_5fmain_5fregion_5fidle_0',['SCVI_MAIN_REGION_IDLE',['../_statechart_8h.html#a25565c2022f289f1815f4169380a5fbb',1,'Statechart.h']]]
];
