var searchData=
[
  ['recipe_0',['Recipe',['../struct_recipe.html',1,'']]],
  ['recipestep_1',['RecipeStep',['../struct_recipe_step.html',1,'']]]
];
