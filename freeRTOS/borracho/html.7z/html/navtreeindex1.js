var NAVTREEINDEX1 =
{
"sc__types_8h_source.html":[1,0,0,0,3],
"struct_control_command.html":[0,0,2],
"struct_display_command.html":[0,0,3],
"struct_recipe.html":[0,0,4],
"struct_recipe_step.html":[0,0,5],
"struct_temperature_data.html":[0,0,9]
};
