var classsc_1_1timer_1_1_timed_interface =
[
    [ "getNumberOfParallelTimeEvents", "classsc_1_1timer_1_1_timed_interface.html#aeaeffef3b4c6c7e803d98f8de2003806", null ],
    [ "getTimerService", "classsc_1_1timer_1_1_timed_interface.html#a45c8c63a653c247bead8aa1f65f34e70", null ],
    [ "raiseTimeEvent", "classsc_1_1timer_1_1_timed_interface.html#a0ad07835d195e9e8d617ead1fd2c4dc0", null ],
    [ "setTimerService", "classsc_1_1timer_1_1_timed_interface.html#a470dc6b4b9c760fb77cca3331d131639", null ]
];