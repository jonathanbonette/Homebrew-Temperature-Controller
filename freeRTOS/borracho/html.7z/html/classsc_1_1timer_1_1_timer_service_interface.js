var classsc_1_1timer_1_1_timer_service_interface =
[
    [ "setTimer", "classsc_1_1timer_1_1_timer_service_interface.html#acec3284a153635da521da46d96cdaf89", null ],
    [ "unsetTimer", "classsc_1_1timer_1_1_timer_service_interface.html#a03ef77388be5d8b25f8b537c2d8fa203", null ]
];